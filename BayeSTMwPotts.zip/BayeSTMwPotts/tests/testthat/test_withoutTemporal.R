### Simulation with theta and w/o theta
library(Rcpp)
library(RcppArmadillo)
library(RcppDist)
library(tidyverse)
library(grid)
library(gridExtra)
library(truncnorm)
library(MASS)
library(BayeSTMwPotts)
rm(list=ls(all=TRUE))

IntegrationSpline = function(ExpU, start, end)
{
  fit = smooth.spline(ExpU[, 1], ExpU[, 2])
  smooth = function(x) predict(fit, x)$y
  value = integrate(smooth, start, end)$value
  return(value)
}

#### Set up ####
num.of.rows = 20
num.of.cols = 20
n = num.of.obs = num.of.rows*num.of.cols
T = 9
p = num.of.covariates = 2
x.easting <- 1:num.of.rows
x.northing <- 1:num.of.cols
Grid <- expand.grid(x.easting, x.northing)## 左下到右上
distance <- as.matrix(dist(Grid, method="euclidean"))
K <- nrow(Grid)

W = array(0, c(K,K))
W[distance==1] = 1

ExpU = ExpU_Evaluation(50, 3, 2, 40, W)


#### Potts Image ####
#2d PottsImage
PottsImage2d = array(0, c(num.of.rows, num.of.cols, 2))
PottsImage2d[c(4:8, 13:17), 13:17, 1] = 1
PottsImage2d[7:14, 4:8, 1] = 2
PottsImage2d[c(4:8, 13:17), 13:17, 2] = 2
PottsImage2d[7:14, 4:8, 2] = 1
##1d PottsImage
PottsImage = cbind(c(PottsImage2d[,,1]), c(PottsImage2d[,,2]))
image(matrix(PottsImage[,1], num.of.rows, num.of.cols))
image(matrix(PottsImage[,2], num.of.rows, num.of.cols))


## Data Generation
## phi
rho = 0.5
lambda = 2
Q = rho*( diag(c( W%*%matrix(1, num.of.obs, 1) ))-W) + (1-rho)*diag(1, num.of.obs)
phi = mvrnorm(1, rep(0, num.of.obs), lambda*solve(Q))

## psi
zeta = 0.2
psi = arima.sim(model=list(ar=zeta),n=T, sd=sqrt(0.1))

## variables
beta.given = PottsImage
beta.given[PottsImage[, 1]==0, 1] = 0
beta.given[PottsImage[, 1]==1, 1] = rtruncnorm(sum(PottsImage[, 1]==1), a=0, b=Inf, mean = 2, sd = 0.1)
beta.given[PottsImage[, 1]==2, 1] = rtruncnorm(sum(PottsImage[, 1]==2), a=-Inf, b=0, mean = -1, sd = 0.1)

beta.given[PottsImage[, 2]==0, 2] = 0
beta.given[PottsImage[, 2]==1, 2] = rtruncnorm(sum(PottsImage[, 2]==1), a=0, b=Inf, mean = 1, sd = 0.1)
beta.given[PottsImage[, 2]==2, 2] = rtruncnorm(sum(PottsImage[, 2]==2), a=-Inf, b=0, mean = -2, sd = 0.1)
beta.given = t(beta.given)
x = array(rnorm(n*p*T), c(T, p, n))
eta = matrix(0, n, T)
for(i in 1:n){
  eta[i, ] = x[, , i]%*%beta.given[, i, drop=F] + psi
}
eta = eta+phi
## Generate y
y = apply(exp(eta), c(1, 2), rpois, n=1)

#### Estimation ####

#1. theta neq 0
## Estimation
IntImage = array(sample(0:2, size = (n*p), replace = TRUE), c(n,p))
IntBeta = dplyr::case_when(
  as.vector(IntImage)==0 ~ 0,
  as.vector(IntImage)==1 ~ 5,
  as.vector(IntImage)==2 ~ -5,
  TRUE ~ NA
) |> array(c(p,n))
InititalValues = list(ActImg = IntImage, beta = beta.given,
                      theta=c(0., 0.), phi = phi, psi = rep(0, T), rho=rho, lambda=1)
# Eit = matrix(mean(y), nrow = T, ncol = n)
Eit = matrix(1, nrow = T, ncol = n)
output = Update_Gamma_Beta_Theta(5000, 3, W, y, x, ExpU, InititalValues, Eit, UpdateTheta = TRUE, UpdatePsi = TRUE)

#2. theta = 0

output2 = Update_Gamma_Beta_Theta(5000, 3, W, y, x, ExpU, InititalValues, Eit, UpdateTheta = TRUE, UpdatePsi = FALSE)



#### consequences ####
Mode <- function(x) {
  ux <- unique(x)
  ux[which.max(tabulate(match(x, ux)))]
}
activation.plot <- function(jj,Grid,z.est.mat,title.string){
  z.Data <- Grid %>% dplyr::mutate(value = as.factor(z.est.mat[,jj]))
  ## z.Data has to include the Grid map and the value of each grid
  ggplot(z.Data, aes(x = Var1,y = Var2))+
    geom_tile(aes(fill = value),colour = "grey50", size = 0.1, alpha = 0.5)+
    scale_shape_manual(name = "category", values = c(0, 1, 2)) +
    scale_fill_manual(name = "category", values = c('0' = "grey95", '1' = "#B40404", '2' = "#0B6121")) +
    scale_x_discrete(breaks=c(1, 5, 10, 15, 20))+
    scale_y_discrete(breaks=c(1, 5, 10, 15, 20))+
    theme(legend.text=element_text(size=7)) +
    ggtitle(title.string) + xlab("x") + ylab("y")
}
EstPottsImage = apply(output$SimActivationImg, c(1, 2), Mode)
p1 <- activation.plot(1,Grid,EstPottsImage, expression("cov1 with" ~theta))
p1
EstPottsImage2 = apply(output2$SimActivationImg, c(1, 2), Mode)
p3 <- activation.plot(1,Grid,EstPottsImage2, expression("cov1 without" ~theta))
p3
