#include <RcppArmadillo.h>
#include <RcppDist.h>
#include <RcppArmadilloExtensions/sample.h>
#include <omp.h>
// [[Rcpp::depends(RcppArmadillo, RcppDist)]]

using namespace Rcpp;
using namespace arma;

//' @export
// [[Rcpp::export]]
NumericVector square_vec(NumericVector x) {
  return x * x;
}


double CalculateUgamma(vec SimImage, arma::mat WeightMat)
{
  //Rcout << "CalculateUgamma" << endl;
  uvec ngh_indices, ngh_same, ngh_row;
  double sum=0;

  //Rcout << SimImage << endl;

  for(int i=0; i<SimImage.n_elem; i++){
    //Rcout << "i = " << i << endl;
    ngh_row = i;
    ngh_indices = find(WeightMat.row(i)>0);
    ngh_same = ngh_indices(find(SimImage(ngh_indices) == SimImage(i)));
    //Rcout << "ngh_indices = " << ngh_indices << endl;
    //Rcout << "ngh_same = " << ngh_same << endl;
    //Rcout << "SimImage(i)" << SimImage(i) << endl;
    //Rcout << "SimImage(ngh_indices)  = " << SimImage(ngh_indices) << endl;
    //Rcout << "WeightMat(ngh_row, ngh_same)" << WeightMat(ngh_row, ngh_same) << endl;
    sum +=  accu(WeightMat(ngh_row, ngh_same)); //ngh_same.n_elem;
  }
  //Rcout << sum << endl;
  //Rcout << "CalculateUgamma Done" << endl;
  return sum;
}


vec SimulatePottsModelCompWise(int iter, double theta, int Num_of_Groups, vec InitialImage, arma::mat WeightMat)
{
  //Rcout << "SimulatePottsModel" << endl;
  uvec ngh_row;
  vec z_prob;
  vec w_sum = zeros<vec>(Num_of_Groups);
  vec group_indices = linspace<vec>(0, Num_of_Groups-1, Num_of_Groups);
  uvec ngh_indices, ngh_same;
  //vec num_of_elms(Num_of_Groups+1);


  for(int k=0; k<iter; k++){
    for(int i=0; i<InitialImage.n_elem; i++){
      ngh_row = i;
      for(int g=0; g<Num_of_Groups; g++){
        ngh_indices = find(WeightMat.row(i)>0);
        ngh_same = ngh_indices(find(InitialImage(ngh_indices) == g));
        w_sum(g) = accu(WeightMat(ngh_row, ngh_same));
      }
      z_prob = exp(theta*w_sum);

      z_prob = z_prob/accu(z_prob);
      //RcppArmadillo::sample(x, size, replace, prob)
      InitialImage(i)= Rcpp::RcppArmadillo::sample(group_indices, 1, true, z_prob)(0);
    }
  }
  //Rcout << "SimulatePottsModel Done" << endl;
  return InitialImage;
}

//' @export
//[[Rcpp::export]]
arma::mat ExpU_Evaluation(int IterTheta, int Num_of_Groups, double theta_max, int NumOfPartition, arma::mat WeightMat)
{
  Rcout << "ExpU_Evaluation" << endl;
  double u_gamma=0;
  int Num_of_obs = WeightMat.n_cols;
  arma::mat ExpU = zeros( NumOfPartition, 2 );
  //ExpU.set_size(NumOfPartition, 2);
  //ExpU.zeros();
  ExpU.col(0) = linspace(0.0, theta_max, NumOfPartition);

  Rcout << ExpU << endl;

  vec SimImage = randi<vec>( Num_of_obs, distr_param(0, (Num_of_Groups-1) ));


  for(unsigned int sep=0; sep<NumOfPartition; sep++){
    for(int iter=0; iter<IterTheta; iter++){
      //Rcout << "ExpU(sep, 0)=" << ExpU(sep, 0) << endl;

      SimImage = SimulatePottsModelCompWise(IterTheta, ExpU(sep, 0), Num_of_Groups, SimImage, WeightMat);

      //SimulatePottsModel(ExpU(sep, 0));
      //Rcout << "check 2" << endl;
      u_gamma = CalculateUgamma(SimImage, WeightMat); //CalculateUgamma(SimImage);
      //Rcout << "ugamma = "  << u_gamma << endl;
      ExpU(sep, 1) += u_gamma/(1.*IterTheta);
    }
    Rcout << "sep = " << sep << "\t ExpU = "<<  ExpU.row(sep) << endl;
    //cout << ExpU[sep][0] << "\t" << sep <<  endl;
  }

  //cout << "finished" << endl;
  //cout << ExpU << endl;
  //cout << SplineIntegration(ExpU, 0.2)<< endl;
  //for(int i=0; i< Nrows; i++)
  //cout << ExpU[i][1] << "\t" << ExpU[i][2] << endl;
  //Rcout << ExpU << endl;
  Rcout << "ExpU_Evaluation Done" << endl;
  return ExpU;
}

//' @export
// [[Rcpp::export]]
double IntegrationC(arma::mat ExpU, double start, double end) {
  // Get the R function from the R global environment
  Function MyIntegrationSpline = Environment::global_env()["IntegrationSpline"];

  SEXP r_result = MyIntegrationSpline(ExpU,start, end);
  if (TYPEOF(r_result) != REALSXP) {
    stop("R function did not return a numeric value.");
  }

  // Call the R function and return its result
  return as<double>(MyIntegrationSpline(ExpU,start, end) );
}

//' @export
// [[Rcpp::export]]
List Update_Gamma_Beta_Theta(int Num_of_Iter, int Num_of_Groups, arma::mat WeightMat, arma::mat Y, arma::cube X, arma::mat ExpU, List IntitalValues, arma::mat Eit, bool UpdateTheta, bool UpdatePsi){
   //Rcout << "SimulatePottsModel" << endl;
   uvec ngh_row, iter_col;
   vec z_prob;
   vec w_sum = zeros<vec>(Num_of_Groups);
   vec group_indices = linspace<vec>(0, Num_of_Groups-1, Num_of_Groups);
   uvec ngh_indices, ngh_same;
   int candpotts;
   int Num_of_obs = WeightMat.n_cols;
   int Num_of_coefs = X.n_cols;
   int Num_of_times = X.n_rows;

   double acc_prob_old, acc_prob_new;
   vec beta_old, beta_new;
   //vec num_of_elms(Num_of_Groups+1);
   arma::cube beta_samples = zeros(Num_of_coefs, Num_of_obs, Num_of_Iter);
   arma::cube ActImg_samples =  randi<arma::cube>(Num_of_obs, Num_of_coefs, Num_of_Iter, distr_param(0, 2));
   arma::mat theta_samples = zeros(Num_of_coefs, Num_of_Iter);
   arma::mat phi_samples = randu<arma::mat>(Num_of_obs, Num_of_Iter);
   arma::mat psi_samples = randu<arma::mat>(Num_of_times, Num_of_Iter);
   arma::cube alpha_samples = zeros<arma::cube>(Num_of_coefs, Num_of_Groups-1, Num_of_Iter);
   arma::cube sigma2_g_samples = ones<arma::cube>(Num_of_coefs, Num_of_Groups-1, Num_of_Iter);
   vec lambda_samples(Num_of_Iter, fill::value(0.01));
   vec rho_samples(Num_of_Iter, fill::value(0.5));//randu(Num_of_Iter);
   vec sigma2_psi_samples(Num_of_Iter, fill::value(0.01));
   vec zeta_samples(Num_of_Iter, fill::value(0.1));
   double theta_old, theta_new;
   double u_gamma, acc_prob, eta;
   double phi_cand, phi_bar, phi_var, phi_sum;
   double rho_cand, rho=0.5, lambda=0.01, zeta = 0.1;
   double eta_old, eta_new, eta_tmp;
   //double eta_tmp_old, eta_tmp_new;
   double neighbor_sum;
   arma::mat  Q_W, Q_W_num, Q_W_den;
   arma::mat IdentityMat(Num_of_obs,Num_of_obs,fill::eye);
   double lambda_alpha, lambda_beta;
   double psi_alpha, psi_beta, psi_cand;
   double zeta_mean, zeta_var, zeta_tmp;

   uvec uvec_beta_index;
   double sigma2_g_alpha, sigma2_g_beta, sigma2_g_tmp;

   Rcout << "Num_of_obs = " << Num_of_obs << endl;
   Rcout << "Num_of_coefs = " << Num_of_coefs << endl;
   Rcout << "Num_of_times =" << Num_of_times << endl;

   //ActImg_samples.slice(0) = as<mat>(IntitalValues["ActImg"]);
   beta_samples.slice(0) = as<arma::mat>(IntitalValues["beta"]);
   phi_samples.col(0) = as<vec>(IntitalValues["phi"]);
   psi_samples.col(0) = as<vec>(IntitalValues["psi"]);
   rho_samples(0) = as<double>(IntitalValues["rho"]);
   lambda_samples(0) = as<double>(IntitalValues["lambda"]);
   theta_samples.col(0) = as<vec>(IntitalValues["theta"]);

   //Rcout << "Read all data" << endl;

   vec betatmp, Xtmp;
   List Output;

   for(int iter=0; iter<(Num_of_Iter-1); iter++){
     if(iter%100==0)
       Rcout << "iter = " << iter << endl;
     iter_col = iter;
     phi_samples.col(iter+1) = phi_samples.col(iter);
     beta_samples.slice(iter+1) = beta_samples.slice(iter);
     ActImg_samples.slice(iter+1) = ActImg_samples.slice(iter);
     rho = rho_samples(iter+1) = rho_samples(iter);
     lambda = lambda_samples(iter+1) = lambda_samples(iter);
     psi_samples.col(iter+1) = psi_samples.col(iter);
     theta_samples.col(iter+1) = theta_samples.col(iter);

     for(int j=0; j<Num_of_coefs; j++){
       for(int i=0; i<Num_of_obs; i++){
         ngh_row = i;
         beta_old = beta_new = beta_samples.slice(iter+1).col(i);
         for(int g=0; g<Num_of_Groups; g++){
           ngh_indices = find(ActImg_samples.subcube(span::all, span(j), span(iter+1)) == g);
           w_sum(g) = accu(WeightMat(ngh_row, ngh_indices));
         }
         z_prob = exp(theta_samples(j, iter)*w_sum);

         candpotts = Rcpp::RcppArmadillo::sample(group_indices, 1, true, z_prob)(0);
         betatmp = beta_samples.slice(iter+1).row(j).t();
         if(candpotts==0)
           beta_new(j) = 0.;
         if(candpotts==1){
           beta_new(j) = r_truncnorm(alpha_samples(j, candpotts-1, iter), sigma2_g_samples(j, candpotts-1, iter), 0, datum::inf);

           //mean(betatmp(find(ActImg_samples.subcube(span::all, span(j), span(iter+1)) == 1)))+r_truncnorm(0, 1, 0, datum::inf);
         }
         if(candpotts==2){
           //Rcout << "iter = " << iter << "\t i = " << i << endl;
           //Rcout << "alpha_samples(" << j << " " << candpotts-1<< " " << iter << ") = " << alpha_samples(j, candpotts-1, iter) << endl;
           beta_new(j) = r_truncnorm(alpha_samples(j, candpotts-1, iter), sigma2_g_samples(j, candpotts-1, iter), -datum::inf, 0); //mean(betatmp(find(ActImg_samples.subcube(span::all, span(j), span(iter+1)) == 2)))+r_truncnorm(0, 1, -datum::inf, 0);
         }

         acc_prob_old = 0;
         acc_prob_new = 0;
         for(int t = 0; t<Num_of_times; t++){
           Xtmp = vectorise(X.subcube(span(t), span::all, span(i)));
           eta_old = as_scalar(Xtmp.t()*beta_old)+ phi_samples(i, iter)+psi_samples(t, iter);
           eta_new = as_scalar(Xtmp.t()*beta_new)+ phi_samples(i, iter)+psi_samples(t, iter);
           acc_prob_old += -Eit(t,i)*exp(eta_old) + Y(i, t)*eta_old ;
           acc_prob_new += -Eit(t,i)*exp(eta_new) + Y(i, t)*eta_new ;
         }


         if(log(randu())< (acc_prob_new-acc_prob_old) ){
           beta_samples(j, i, iter+1) = beta_new(j);
           ActImg_samples(i, j, iter+1) = candpotts;
         }
       }
     }


     if(UpdateTheta){
       for(int j=0; j<Num_of_coefs; j++){
         u_gamma = CalculateUgamma(ActImg_samples.subcube(span::all, span(j), span(iter+1)), WeightMat);

         do{
           theta_old = theta_samples(j, iter+1) = theta_samples(j, iter);
           theta_new = theta_old + 0.05*randn();
         }while(theta_new<0 || theta_new>2);
         acc_prob = IntegrationC(ExpU, theta_new, theta_old)+(theta_new-theta_old)*u_gamma;
         if( log(randu())< acc_prob){
           theta_samples(j, iter+1) = theta_new;
           //acceptance_rate++;
         }
       }
     }


     for(int i=0; i<Num_of_obs; i++){
       //ngh_row = i;
       phi_sum = as_scalar(WeightMat.row(i)*phi_samples.col(iter+1));
       neighbor_sum = accu(WeightMat.row(i));
       phi_bar = rho*phi_sum/(rho*neighbor_sum+1-rho);
       phi_var = lambda/(rho*neighbor_sum+1-rho);
       phi_cand = phi_samples(i, iter)+0.05*randn();
       //eta_tmp = as_scalar(X.row(i)*beta_samples.slice(iter+1).col(i));
       acc_prob_old=0;
       acc_prob_new=0;
       for(int t = 0; t<Num_of_times; t++){
         //Rcout << "j = " << j << "\t i = " << i << "\t t = " << t << endl;
         Xtmp = vectorise(X.subcube(span(t), span::all, span(i)));
         betatmp = beta_samples.slice(iter+1).col(i);
         //Rcout << "etatmp.t()" << etatmp << endl;
         //Rcout << "etatmp.t()*beta_old = " << etatmp.t()*beta_old << endl;
         eta_old = as_scalar(Xtmp.t()*betatmp)+ phi_samples(i, iter+1)+psi_samples(t, iter);
         eta_new = as_scalar(Xtmp.t()*betatmp)+ phi_cand +psi_samples(t, iter);

         acc_prob_old += -Eit(t, i)*exp(eta_old) + Y(i, t)*eta_old ;
         acc_prob_new += -Eit(t, i)*exp(eta_new) + Y(i, t)*eta_new ;
       }

       acc_prob_old = acc_prob_old - 0.5*pow((phi_samples(i, iter+1)-phi_bar), 2.)/phi_var;

       acc_prob_new = acc_prob_new - 0.5*pow((phi_cand-phi_bar), 2.)/phi_var;

       if(log(randu())< (acc_prob_new-acc_prob_old) ){
         phi_samples(i, iter+1) = phi_cand;
       }

     }

     Q_W = rho*( diagmat(sum(WeightMat, 0))-WeightMat ) + (1. - rho)* IdentityMat;
     lambda_alpha = 0.5*(Num_of_obs+1.);
     lambda_beta = 0.5*(as_scalar(phi_samples.col(iter+1).t() * Q_W * phi_samples.col(iter+1)) + 1);
     //Rcout << "33" << endl;
     lambda_samples(iter+1) = 1./randg( distr_param(lambda_alpha, 1./lambda_beta) );
     //Rcout << "44" << endl;

     do{
       rho_cand = rho_samples(iter)+randu( distr_param(-0.1,0.1));
     }
     while (rho_cand<0 || rho_cand>1);

     //rho_cand = rho_samples(iter)+0.05*randn();
     //rho_samples(iter+1) = rho_samples(iter);


     Q_W_num = rho_cand* ( diagmat(sum(WeightMat, 0))-WeightMat ) + (1. - rho_cand)* IdentityMat;
     Q_W_den = rho_samples(iter)* ( diagmat(sum(WeightMat, 0))-WeightMat ) + (1. - rho_samples(iter))* IdentityMat;

     acc_prob_new =  0.5 * log(det(Q_W_num)) -  0.5*as_scalar(phi_samples.col(iter+1).t()*Q_W_num*phi_samples.col(iter+1))/ lambda_samples(iter+1);

     acc_prob_old =  0.5 * log(det(Q_W_den)) - 0.5*as_scalar(phi_samples.col(iter+1).t()*Q_W_den*phi_samples.col(iter+1))/ lambda_samples(iter+1);

     if(log(randu())< (acc_prob_new-acc_prob_old) ){
       rho_samples(iter+1) = rho_cand;
     }
     if(UpdatePsi){
       for(int t = 0; t<Num_of_times; t++){
         //ngh_row = i;
         psi_cand = psi_samples(t, iter+1)+0.01*randn();
         //eta_tmp = as_scalar(X.row(i)*beta_samples.slice(iter+1).col(i));
         acc_prob_old=0;
         acc_prob_new=0;
         for(int i=0; i<Num_of_obs; i++){
           //Rcout << "j = " << j << "\t i = " << i << "\t t = " << t << endl;
           Xtmp = vectorise(X.subcube(span(t), span::all, span(i)));
           betatmp = beta_samples.slice(iter+1).col(i);
           //Rcout << "etatmp.t()" << etatmp << endl;
           //Rcout << "etatmp.t()*beta_old = " << etatmp.t()*beta_old << endl;
           eta_old = as_scalar(Xtmp.t()*betatmp)+ phi_samples(i, iter+1)+psi_samples(t, iter+1);
           eta_new = as_scalar(Xtmp.t()*betatmp)+ phi_samples(i, iter+1)+psi_cand;

           acc_prob_old += -Eit(t,i)*exp(eta_old) + Y(i, t)*eta_old ;
           acc_prob_new += -Eit(t,i)*exp(eta_new) + Y(i, t)*eta_new ;
         }

         if(t==0){
           acc_prob_old = acc_prob_old - 0.5*pow(psi_samples(t, iter+1), 2.)/sigma2_psi_samples(iter);

           acc_prob_new = acc_prob_new - 0.5*pow(psi_cand, 2.)/sigma2_psi_samples(iter);
         }
         else{
           acc_prob_old = acc_prob_old - 0.5*pow((psi_samples(t, iter+1)-zeta*psi_samples(t-1, iter+1)), 2.)/sigma2_psi_samples(iter);

           acc_prob_new = acc_prob_new - 0.5*pow((psi_cand-zeta*psi_samples(t-1, iter+1)), 2.)/sigma2_psi_samples(iter);
         }
         //Rcout << "acc_prob_old = " << acc_prob_old << endl;
         //Rcout << "acc_prob_new = " << acc_prob_new << endl;
         //Rcout << "acc_prob_new-acc_prob_old = " << acc_prob_new-acc_prob_old << endl;
         if(log(randu())< (acc_prob_new-acc_prob_old) ){
           psi_samples(t, iter+1) = psi_cand;
         }
       }
     }



     //psi_samples.col(iter+1) = psi_samples.col(iter);

     zeta_tmp = accu(psi_samples(span(0, Num_of_times-2), span(iter+1)).t()*psi_samples(span(0, Num_of_times-2), span(iter+1)));

     zeta_mean = accu(psi_samples(span(1, Num_of_times-1), span(iter+1)).t()*psi_samples(span(0, Num_of_times-2), span(iter+1)));

     zeta_mean = zeta_mean/zeta_tmp;
     zeta_var = sigma2_psi_samples(iter)/zeta_tmp;
     zeta_samples(iter+1) = randn( distr_param(zeta_mean,sqrt(zeta_var)) );


     psi_alpha = 0.5*(Num_of_times+1.);
     psi_beta = 0.5* (accu(square( psi_samples(span(1, Num_of_times-1), span(iter)) - zeta*psi_samples(span(0, Num_of_times-2), span(iter) ) ))+1);
     sigma2_psi_samples(iter+1) = 1./randg( distr_param(psi_alpha, 1./psi_beta) );


     for(int j=0; j<Num_of_coefs; j++){
       betatmp = beta_samples.slice(iter+1).row(j).t();

       //if(j==1)
       //Rcout << "j=1 uvec_beta_index.n_elem = " << betatmp << endl;

       uvec_beta_index = find(ActImg_samples.subcube(span::all, span(j), span(iter+1)) == 1);
       //Rcout << "1 uvec_beta_index.n_elem = " << uvec_beta_index.n_elem << endl;
       if(uvec_beta_index.n_elem <3 ){
         //Rcout << "12 uvec_beta_index.is_empty() = " << uvec_beta_index.is_empty() << endl;
         sigma2_g_samples(j, 0, iter+1) = 1e-10;
         alpha_samples(j, 0, iter+1) = 0;
       }
       else{
         //Rcout << "1" << endl;
         sigma2_g_tmp = sigma2_g_samples(j, 0, iter)/uvec_beta_index.n_elem;
         alpha_samples(j, 0, iter+1) = mean(betatmp(uvec_beta_index))+r_truncnorm(0, sigma2_g_tmp, 0, datum::inf);
         sigma2_g_alpha = uvec_beta_index.n_elem+1;
         sigma2_g_beta = accu(square(betatmp(uvec_beta_index)-alpha_samples(j, 0, iter+1)))+1;
         if(sigma2_g_beta==datum::inf) {sigma2_g_beta = 100000;}
         //Rcout << "uvec_beta_index.n_elem = " << uvec_beta_index.n_elem << endl;

         if(0){
           Rcout << "uvec_beta_index.n_elem = " << uvec_beta_index.n_elem << endl;
           Rcout << "beta = " << betatmp(uvec_beta_index) << endl;
           //Rcout << " mean = " << mean(betatmp(uvec_beta_index)) << endl;
           Rcout << "sigma2_g_tmp = " << sigma2_g_tmp << endl;
           Rcout << "alpha_samples(j = " << j << ", 0, iter+1) = " << alpha_samples(j, 0, iter+1) << endl;
           Rcout << "sigma2_g_alpha = " << sigma2_g_alpha << endl;
           Rcout << "sigma2_g_beta = " << sigma2_g_beta << endl;
         }
         sigma2_g_samples(j, 0, iter+1) = 1./randg( distr_param(sigma2_g_alpha, 1./sigma2_g_beta) );
       }

       uvec_beta_index = find(ActImg_samples.subcube(span::all, span(j), span(iter+1)) == 2);
       //Rcout << "2 uvec_beta_index.n_elem = " << uvec_beta_index.n_elem << endl;
       //Rcout << "2 uvec_beta_index.n_elem = " << uvec_beta_index.n_elem << endl;
       if(uvec_beta_index.n_elem <3){
         //Rcout << "22 uvec_beta_index.is_empty() = " << uvec_beta_index.is_empty() << endl;
         sigma2_g_samples(j, 1, iter+1) = 1e-10;
         alpha_samples(j, 1, iter+1) = 0;
       }
       else{
         //Rcout << "2" << endl;
         //Rcout << "uvec_beta_index.is_empty() = " << uvec_beta_index.empty() << endl;
         //Rcout<< "beta = " << betatmp(uvec_beta_index) << " mean = " << mean(betatmp(uvec_beta_index)) << endl;
         sigma2_g_tmp = sigma2_g_samples(j, 1, iter)/uvec_beta_index.n_elem;
         alpha_samples(j, 1, iter+1) = mean(betatmp(uvec_beta_index))+r_truncnorm(0, sigma2_g_tmp, -datum::inf, 0);
         sigma2_g_alpha = uvec_beta_index.n_elem+1;
         sigma2_g_beta = accu(square(betatmp(uvec_beta_index)-alpha_samples(j, 1, iter+1)))+1;
         if(sigma2_g_beta==datum::inf) {sigma2_g_beta = 100000;}
         if(0){
           Rcout << "uvec_beta_index.n_elem = " << uvec_beta_index.n_elem << endl;
           Rcout << "beta = " << betatmp(uvec_beta_index) << endl;
           //Rcout << " mean = " << mean(betatmp(uvec_beta_index)) << endl;
           Rcout << "sigma2_g_tmp = " << sigma2_g_tmp << endl;
           Rcout << "alpha_samples(j = "<< j << ", 1, iter+1) = " << alpha_samples(j, 1, iter+1) << endl;
           Rcout << "sigma2_g_alpha = " << sigma2_g_alpha << endl;
           Rcout << "sigma2_g_beta = " << sigma2_g_beta << endl;
         }
         sigma2_g_samples(j, 1, iter+1) = 1./randg( distr_param(sigma2_g_alpha, 1./sigma2_g_beta) );
         //Rcout << "2222" << endl;
         //alpha_samples(j, 1, iter+1) = mean(betatmp(find(ActImg_samples.subcube(span::all, span(j), span(iter+1)) == 2)))+r_truncnorm(0, 1, -datum::inf, 0);
       }
     }
   }

   Output["SimActivationImg"] = ActImg_samples;
   Output["beta_samples"] = beta_samples;
   Output["theta_samples"] = theta_samples;
   Output["phi_samples"] = phi_samples;
   Output["lambda_samples"] = lambda_samples;
   Output["rho_samples"] = rho_samples;
   Output["zeta_samples"] = zeta_samples;
   Output["psi_sigma2_samples"] = sigma2_psi_samples;
   Output["psi_samples"] = psi_samples;
   Output["alpha_samples"] = alpha_samples;
   Output["sigma2_g_samples"] = sigma2_g_samples;
   return(Output);
 }

